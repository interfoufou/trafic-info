import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// جلب طلبات الطوارئ
export async function GET(request: NextRequest) {
  try {
    const emergencies = await db.emergencyRequest.findMany({
      where: { status: 'pending' },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({ success: true, data: emergencies });
  } catch (error) {
    console.error('Error fetching emergencies:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب طلبات الطوارئ' },
      { status: 500 }
    );
  }
}

// إرسال طلب طوارئ جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, description, latitude, longitude, location, phone } = body;

    const emergency = await db.emergencyRequest.create({
      data: {
        type: type || 'other',
        description,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        location,
        phone,
      },
    });

    return NextResponse.json({ 
      success: true, 
      data: emergency,
      message: 'تم إرسال طلب الطوارئ بنجاح' 
    });
  } catch (error) {
    console.error('Error creating emergency:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إرسال طلب الطوارئ' },
      { status: 500 }
    );
  }
}
