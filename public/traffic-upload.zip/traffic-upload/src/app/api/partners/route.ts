import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// جلب الشركاء
export async function GET(request: NextRequest) {
  try {
    const partners = await db.partner.findMany({
      where: { isVerified: true },
      include: {
        _count: {
          select: { alerts: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: partners });
  } catch (error) {
    console.error('Error fetching partners:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب الشركاء' },
      { status: 500 }
    );
  }
}

// إضافة شريك جديد
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, type, logo, phone, email, address, description, userId } = body;

    const partner = await db.partner.create({
      data: {
        name,
        type,
        logo,
        phone,
        email,
        address,
        description,
        userId,
      },
    });

    return NextResponse.json({ success: true, data: partner });
  } catch (error) {
    console.error('Error creating partner:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إضافة الشريك' },
      { status: 500 }
    );
  }
}
