import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// بيانات تجريبية للتطبيق
export async function GET() {
  try {
    // إضافة مركز إدارة شرطة المرور الرئيسي
    await db.policeStation.upsert({
      where: { id: 'main-traffic-hq' },
      create: {
        id: 'main-traffic-hq',
        name: 'إدارة شرطة المرور',
        address: 'شارع الجمهورية 1001 تونس',
        phone: '71 343 201',
        latitude: 36.7995,
        longitude: 10.1789,
        type: 'traffic',
        isOpen24h: true,
      },
      update: {},
    });

    // إضافة أرقام الطوارئ
    const emergencyStations = [
      {
        id: 'emergency-ambulance',
        name: 'الإسعاف - SAMU',
        address: 'خدمة الطوارئ الوطنية',
        phone: '190',
        latitude: 36.8065,
        longitude: 10.1815,
        type: 'emergency' as const,
        isOpen24h: true,
      },
      {
        id: 'emergency-civil-protection',
        name: 'الحماية المدنية',
        address: 'خدمة الطوارئ الوطنية',
        phone: '198',
        latitude: 36.8065,
        longitude: 10.1815,
        type: 'emergency' as const,
        isOpen24h: true,
      },
      {
        id: 'emergency-police',
        name: 'النجدة - Police Secours',
        address: 'خدمة الطوارئ الوطنية',
        phone: '197',
        latitude: 36.8065,
        longitude: 10.1815,
        type: 'police' as const,
        isOpen24h: true,
      },
    ];

    for (const station of emergencyStations) {
      await db.policeStation.upsert({
        where: { id: station.id },
        create: station,
        update: {},
      });
    }

    // إضافة أخبار تجريبية
    const newsData = [
      {
        id: 'news-1',
        title: 'تنبيه: إغلاق شارع الحبيب بورقيبة للصيانة',
        content: 'يتم إغلاق شارع الحبيب بورقيبة من جانب محطة المترو إلى جانب السفارة الفرنسية لأعمال صيانة من الساعة 22:00 إلى 06:00',
        category: 'urgent',
        source: 'إدارة شرطة المرور',
      },
      {
        id: 'news-2',
        title: 'حركة مرور كثيفة على الطريق السيار تونس-صفاقس',
        content: 'تنبه شرطة المرور من حركة مرور كثيفة على الطريق السيار تونس-صفاقس بسبب عطلة نهاية الأسبوع',
        category: 'warning',
        source: 'إدارة شرطة المرور',
      },
      {
        id: 'news-3',
        title: 'حملة مرورية موسعة ابتداء من الغد',
        content: 'أعلنت مديرية المرور الوطنية عن حملة مرورية موسعة للتحقق من وثائق السيارات ورخص القيادة',
        category: 'info',
        source: 'وزارة الداخلية',
      },
      {
        id: 'news-4',
        title: 'أشغال على جسر رادس',
        content: 'تنبيه من أشغال صيانة على جسر رادس قد تسبب إكتظاظاً مرورياً في الفترة الصباحية',
        category: 'warning',
        source: 'إدارة شرطة المرور',
      },
    ];

    for (const news of newsData) {
      await db.news.upsert({
        where: { id: news.id },
        create: news,
        update: {},
      });
    }

    // إضافة بلاغات تجريبية
    const reportsData = [
      {
        id: 'report-1',
        type: 'roadwork',
        title: 'أشغال بالطريق على شارع الحبيب بورقيبة',
        description: 'أشغال صيانة للبنية التحتية - فترة العمل من 22:00 إلى 06:00',
        latitude: 36.7995,
        longitude: 10.1789,
        location: 'شارع الحبيب بورقيبة، تونس العاصمة',
        priority: 'high',
      },
      {
        id: 'report-2',
        type: 'traffic_jam',
        title: 'إكتظاظ مروري كثيف',
        description: 'إكتظاظ بسبب كثافة حركة السير',
        latitude: 36.8156,
        longitude: 10.1658,
        location: 'الطريق السيار A1، تونس',
        priority: 'medium',
      },
      {
        id: 'report-3',
        type: 'accident',
        title: 'حادث مروري بسيط',
        description: 'حادث تصادم بسيط بدون إصابات - تم إبلاغ الشرطة',
        latitude: 36.8089,
        longitude: 10.1895,
        location: 'ساحة الباسيج، تونس',
        priority: 'high',
      },
      {
        id: 'report-4',
        type: 'camera',
        title: 'رادار سرعة ثابت',
        description: 'رادار ثابت لمراقبة السرعة - السرعة القصوى 80 كم/س',
        latitude: 36.8456,
        longitude: 10.1956,
        location: 'الطريق السيار تونس-حلق الوادي',
        priority: 'low',
      },
      {
        id: 'report-5',
        type: 'hazard',
        title: 'حفرة كبيرة على الطريق',
        description: 'حفرة خطيرة قد تسبب أضراراً للسيارات - يُرجى الحذر',
        latitude: 36.8123,
        longitude: 10.1734,
        location: 'شارع محمد الخامس، تونس',
        priority: 'urgent',
      },
      {
        id: 'report-6',
        type: 'roadwork',
        title: 'أشغال توسعة الطريق',
        description: 'أشغال توسعة وإصلاح الطريق - مدة الأشغال 3 أشهر',
        latitude: 36.8234,
        longitude: 10.1456,
        location: 'طريقغرافة، تونس',
        priority: 'high',
      },
    ];

    for (const report of reportsData) {
      await db.report.upsert({
        where: { id: report.id },
        create: report,
        update: {},
      });
    }

    return NextResponse.json({
      success: true,
      message: 'تم إضافة البيانات التجريبية بنجاح',
      data: {
        policeStations: 4,
        news: 4,
        reports: 6,
      },
    });
  } catch (error) {
    console.error('Error seeding data:', error);
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في إضافة البيانات' },
      { status: 500 }
    );
  }
}
