'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Car,
  Users,
  Phone,
  Settings,
  Globe,
  MapPin,
  Clock,
  AlertTriangle,
  Send,
  Image,
  ThumbsUp,
  Eye,
  X,
  CheckCircle,
  AlertCircle,
  Loader2,
  Navigation,
  Map,
  Mail
} from 'lucide-react';

// Translations
const translations = {
  ar: {
    appName: 'TRAFFIC INFO TUNISIE',
    subtitle: 'إدارة شرطة المرور',
    country: 'الجمهورية التونسية',
    ministry: 'وزارة الداخلية',
    tabs: {
      safety: 'السلامة المرورية',
      citizen: 'فضاء المواطن',
      contact: 'التواصل',
      services: 'الخدمات',
    },
    address: 'شارع الجمهورية 1001 تونس',
    sections: {
      safety: {
        title: 'السلامة المرورية',
        subtitle: 'معلومات حديثة عن حالة الطرق',
        congestion: 'الإكتظاظ المروري',
        reports: 'البلاغات المرورية',
        roadworks: 'الأشغال بالطريق',
        events: 'التظاهرات',
        liveReports: 'البلاغات المباشرة',
        noReports: 'لا توجد بلاغات حالياً',
        loading: 'جاري التحميل...',
        vote: 'تصويت',
        views: 'مشاهدة',
        active: 'نشط',
        resolved: 'تم الحل',
      },
      citizen: {
        title: 'فضاء المواطن المسؤول',
        subtitle: 'ساهم في تحسين السلامة المرورية',
        sendAlert: 'إرسال تنبيه',
        photos: 'صور',
        videos: 'فيديو',
        message: 'رسالة',
        form: {
          type: 'نوع التنبيه',
          title: 'عنوان التنبيه',
          description: 'وصف تفصيلي',
          location: 'الموقع',
          useMyLocation: 'استخدم موقعي الحالي',
          addImages: 'إضافة صور',
          submit: 'إرسال التنبيه',
          cancel: 'إلغاء',
          success: 'تم إرسال التنبيه بنجاح!',
          types: {
            traffic_jam: 'إكتظاظ مروري',
            accident: 'حادث مروري',
            roadwork: 'أشغال بالطريق',
            hazard: 'خطر على الطريق',
            police: 'نقطة شرطة',
            camera: 'رادار آلي',
            closure: 'إغلاق طريق',
            other: 'أخرى',
          }
        }
      },
      contact: {
        title: 'التواصل',
        subtitle: 'مع إدارة شرطة المرور',
        emergency: 'أرقام الطوارئ',
        police: 'النجدة',
        ambulance: 'الإسعاف',
        civilProtection: 'الحماية المدنية',
        workingHours: 'خدمة 24/24 ساعة',
      },
      services: {
        title: 'خدمات إدارة شرطة المرور',
        subtitle: 'جميع الخدمات في متناول يدك',
        license: 'رخصة السياقة',
        roadworkPermit: 'تراخيص الأشغال بالطريق',
        radar: 'الرادار الآلي',
        violations: 'المخالفات المرورية',
        accidents: 'الحوادث المرورية',
        eservices: 'الخدمات الإلكترونية',
        faq: 'الأسئلة المتداولة',
      },
    },
  },
  fr: {
    appName: 'TRAFFIC INFO TUNISIE',
    subtitle: 'Administration de Police de Circulation',
    country: 'République Tunisienne',
    ministry: 'Ministère de l\'Intérieur',
    tabs: {
      safety: 'Sécurité Routière',
      citizen: 'Espace Citoyen',
      contact: 'Contact',
      services: 'Services',
    },
    address: 'Rue de la République 1001 Tunis',
    sections: {
      safety: {
        title: 'Sécurité Routière',
        subtitle: 'Informations sur l\'état des routes',
        congestion: 'Encombrement',
        reports: 'Signalements',
        roadworks: 'Travaux',
        events: 'Événements',
        liveReports: 'Signalements en direct',
        noReports: 'Aucun signalement',
        loading: 'Chargement...',
        vote: 'vote',
        views: 'vues',
        active: 'actif',
        resolved: 'résolu',
      },
      citizen: {
        title: 'Espace Citoyen Responsable',
        subtitle: 'Contribuez à la sécurité routière',
        sendAlert: 'Envoyer une alerte',
        photos: 'Photos',
        videos: 'Vidéos',
        message: 'Message',
        form: {
          type: 'Type d\'alerte',
          title: 'Titre',
          description: 'Description',
          location: 'Localisation',
          useMyLocation: 'Utiliser ma position',
          addImages: 'Ajouter des images',
          submit: 'Envoyer',
          cancel: 'Annuler',
          success: 'Alerte envoyée!',
          types: {
            traffic_jam: 'Embouteillage',
            accident: 'Accident',
            roadwork: 'Travaux',
            hazard: 'Danger',
            police: 'Police',
            camera: 'Radar',
            closure: 'Route barrée',
            other: 'Autre',
          }
        }
      },
      contact: {
        title: 'Contact',
        subtitle: 'Administration de Police de Circulation',
        emergency: 'Numéros d\'urgence',
        police: 'Police Secours',
        ambulance: 'SAMU',
        civilProtection: 'Protection Civile',
        workingHours: 'Service 24/24h',
      },
      services: {
        title: 'Services',
        subtitle: 'Tous les services à votre disposition',
        license: 'Permis de conduire',
        roadworkPermit: 'Autorisations de travaux',
        radar: 'Radar automatique',
        violations: 'Infractions',
        accidents: 'Accidents',
        eservices: 'E-Services',
        faq: 'FAQ',
      },
    },
  },
  en: {
    appName: 'TRAFFIC INFO TUNISIE',
    subtitle: 'Traffic Police Administration',
    country: 'Republic of Tunisia',
    ministry: 'Ministry of Interior',
    tabs: {
      safety: 'Road Safety',
      citizen: 'Citizen Space',
      contact: 'Contact',
      services: 'Services',
    },
    address: 'Republic Street 1001 Tunis',
    sections: {
      safety: {
        title: 'Road Safety',
        subtitle: 'Latest road condition information',
        congestion: 'Traffic Congestion',
        reports: 'Reports',
        roadworks: 'Road Works',
        events: 'Events',
        liveReports: 'Live Reports',
        noReports: 'No reports at the moment',
        loading: 'Loading...',
        vote: 'vote',
        views: 'views',
        active: 'active',
        resolved: 'resolved',
      },
      citizen: {
        title: 'Responsible Citizen Space',
        subtitle: 'Contribute to road safety',
        sendAlert: 'Send Alert',
        photos: 'Photos',
        videos: 'Videos',
        message: 'Message',
        form: {
          type: 'Alert Type',
          title: 'Alert Title',
          description: 'Description',
          location: 'Location',
          useMyLocation: 'Use my location',
          addImages: 'Add Images',
          submit: 'Send Alert',
          cancel: 'Cancel',
          success: 'Alert sent successfully!',
          types: {
            traffic_jam: 'Traffic Jam',
            accident: 'Accident',
            roadwork: 'Road Work',
            hazard: 'Hazard',
            police: 'Police',
            camera: 'Speed Camera',
            closure: 'Road Closure',
            other: 'Other',
          }
        }
      },
      contact: {
        title: 'Contact',
        subtitle: 'Traffic Police Administration',
        emergency: 'Emergency Numbers',
        police: 'Emergency Police',
        ambulance: 'Ambulance',
        civilProtection: 'Civil Protection',
        workingHours: '24/7 Service',
      },
      services: {
        title: 'Traffic Police Services',
        subtitle: 'All services at your fingertips',
        license: 'Driving License',
        roadworkPermit: 'Road Work Permits',
        radar: 'Speed Camera',
        violations: 'Violations',
        accidents: 'Accidents',
        eservices: 'E-Services',
        faq: 'FAQ',
      },
    },
  },
};

type Language = 'ar' | 'fr' | 'en';
type Tab = 'safety' | 'citizen' | 'contact' | 'services';

const reportTypeIcons: Record<string, string> = {
  traffic_jam: '🚗',
  accident: '🚨',
  roadwork: '🚧',
  hazard: '⚠️',
  police: '🚔',
  camera: '📷',
  closure: '⛔',
  other: '📢',
};

// Mock reports data
const mockReports = [
  {
    id: '1',
    type: 'traffic_jam',
    title: 'إكتظاظ مروري على طريق مدنين',
    description: 'ازدحام شديد بسبب حادث مروري',
    location: 'طريق مدنين - قابس',
    status: 'active',
    votes: 15,
    views: 120,
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    type: 'roadwork',
    title: 'أشغال بالطريق الوطنية رقم 1',
    description: 'أشغال صيانة على الطريق الوطنية رقم 1',
    location: 'الطريق الوطنية رقم 1 - تونس',
    status: 'active',
    votes: 8,
    views: 45,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('safety');
  const [language, setLanguage] = useState<Language>('ar');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [alertDialogOpen, setAlertDialogOpen] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [formData, setFormData] = useState({
    type: '',
    title: '',
    description: '',
    location: '',
  });

  const t = translations[language];
  const isRTL = language === 'ar';

  const tabs = [
    { id: 'safety' as Tab, label: t.tabs.safety, icon: Car },
    { id: 'citizen' as Tab, label: t.tabs.citizen, icon: Users },
    { id: 'contact' as Tab, label: t.tabs.contact, icon: Phone },
    { id: 'services' as Tab, label: t.tabs.services, icon: Settings },
  ];

  const handleSubmitAlert = () => {
    setSubmitSuccess(true);
    setTimeout(() => {
      setAlertDialogOpen(false);
      setSubmitSuccess(false);
      setFormData({ type: '', title: '', description: '', location: '' });
    }, 2000);
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (minutes < 60) {
      return language === 'ar' ? `منذ ${minutes} دقيقة` : 
             language === 'fr' ? `Il y a ${minutes} min` : `${minutes}m ago`;
    } else {
      return language === 'ar' ? `منذ ${hours} ساعة` :
             language === 'fr' ? `Il y a ${hours}h` : `${hours}h ago`;
    }
  };

  return (
    <div className={`min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white ${isRTL ? '' : 'ltr'}`}>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-blue-100 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-lg">
                🚗
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg md:text-xl font-bold text-blue-700">{t.appName}</h1>
                <p className="text-xs text-gray-500">{t.subtitle}</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-gray-600 hover:bg-blue-50'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                </button>
              ))}
            </nav>

            {/* Language Selector */}
            <div className="flex items-center gap-2">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm"
              >
                <option value="ar">🇹🇳 العربية</option>
                <option value="fr">🇫🇷 Français</option>
                <option value="en">🇬🇧 English</option>
              </select>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-blue-50"
              >
                <Car className="h-6 w-6 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden pb-4 border-t border-blue-100 mt-2 pt-4">
              <div className="grid grid-cols-2 gap-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-medium ${
                      activeTab === tab.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-blue-50 text-gray-600'
                    }`}
                  >
                    <tab.icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                ))}
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-4 pb-24 md:pb-6">
        {/* Safety Section */}
        {activeTab === 'safety' && (
          <div className="space-y-4">
            <Card className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-2">{t.sections.safety.title}</h2>
                    <p className="text-blue-100 text-sm">{t.sections.safety.subtitle}</p>
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <Car className="h-8 w-8" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Categories */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { icon: '🚦', label: t.sections.safety.congestion, color: 'bg-gradient-to-br from-red-500 to-orange-500' },
                { icon: '📢', label: t.sections.safety.reports, color: 'bg-gradient-to-br from-blue-500 to-cyan-500' },
                { icon: '🚧', label: t.sections.safety.roadworks, color: 'bg-gradient-to-br from-amber-500 to-yellow-500' },
                { icon: '🎭', label: t.sections.safety.events, color: 'bg-gradient-to-br from-purple-500 to-pink-500' },
              ].map((cat, idx) => (
                <Card key={idx} className={`${cat.color} p-3 text-center text-white cursor-pointer hover:scale-105 transition-transform`}>
                  <div className="text-2xl mb-1">{cat.icon}</div>
                  <h3 className="text-xs font-semibold">{cat.label}</h3>
                </Card>
              ))}
            </div>

            {/* Live Reports */}
            <Card className="shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-blue-700 flex items-center gap-2">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                    {t.sections.safety.liveReports}
                  </h3>
                  <Badge className="bg-blue-100 text-blue-700">{mockReports.length}</Badge>
                </div>

                <div className="space-y-3">
                  {mockReports.map((report) => (
                    <Card key={report.id} className="p-4 bg-gray-50">
                      <div className="flex items-start gap-3">
                        <div className="text-2xl">{reportTypeIcons[report.type] || '📢'}</div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold text-gray-800">{report.title}</h4>
                            <Badge variant="outline" className="border-green-500 text-green-600">
                              {t.sections.safety.active}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{report.description}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {report.location}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatTimeAgo(report.createdAt)}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 mt-2 pt-2 border-t">
                            <span className="flex items-center gap-1 text-xs text-blue-600">
                              <ThumbsUp className="h-3 w-3" />
                              {report.votes} {t.sections.safety.vote}
                            </span>
                            <span className="flex items-center gap-1 text-xs text-gray-400">
                              <Eye className="h-3 w-3" />
                              {report.views} {t.sections.safety.views}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Citizen Section */}
        {activeTab === 'citizen' && (
          <div className="space-y-4">
            <Card className="bg-gradient-to-l from-green-600 to-green-700 text-white border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-1">{t.sections.citizen.title}</h2>
                    <p className="text-green-100 text-sm">{t.sections.citizen.subtitle}</p>
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <Users className="h-8 w-8" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Media Options */}
            <Card className="shadow-lg">
              <CardContent className="p-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-4 bg-blue-50 rounded-xl">
                    <div className="text-3xl mb-2">📸</div>
                    <p className="text-sm font-medium">{t.sections.citizen.photos}</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-xl">
                    <div className="text-3xl mb-2">🎥</div>
                    <p className="text-sm font-medium">{t.sections.citizen.videos}</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-xl">
                    <div className="text-3xl mb-2">💬</div>
                    <p className="text-sm font-medium">{t.sections.citizen.message}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alert Dialog */}
            <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg shadow-lg">
                  <Send className="h-5 w-5 mr-2" />
                  {t.sections.citizen.sendAlert}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-green-700">{t.sections.citizen.sendAlert}</DialogTitle>
                </DialogHeader>

                {submitSuccess ? (
                  <div className="text-center py-8">
                    <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                    <p className="text-lg font-medium text-green-600">{t.sections.citizen.form.success}</p>
                  </div>
                ) : (
                  <div className="space-y-4 pt-4">
                    <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder={t.sections.citizen.form.type} />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(t.sections.citizen.form.types).map(([key, value]) => (
                          <SelectItem key={key} value={key}>
                            {reportTypeIcons[key]} {value}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder={t.sections.citizen.form.title}
                    />

                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder={t.sections.citizen.form.description}
                      rows={3}
                    />

                    <div className="flex gap-2">
                      <Input
                        value={formData.location}
                        onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                        placeholder={t.sections.citizen.form.location}
                        className="flex-1"
                      />
                      <Button variant="outline">
                        <Navigation className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" className="flex-1" onClick={() => setAlertDialogOpen(false)}>
                        {t.sections.citizen.form.cancel}
                      </Button>
                      <Button className="flex-1 bg-green-600 hover:bg-green-700" onClick={handleSubmitAlert}>
                        <Send className="h-4 w-4 mr-2" />
                        {t.sections.citizen.form.submit}
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        )}

        {/* Contact Section */}
        {activeTab === 'contact' && (
          <div className="space-y-4">
            <Card className="bg-gradient-to-l from-blue-700 to-blue-800 text-white border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-1">{t.sections.contact.title}</h2>
                    <p className="text-blue-100 text-sm">{t.sections.contact.subtitle}</p>
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <Phone className="h-8 w-8" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emergency Numbers */}
            <Card className="shadow-lg">
              <CardContent className="p-4 space-y-3">
                <h3 className="font-bold text-red-600 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  {t.sections.contact.emergency}
                </h3>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">🚔</span>
                      <div>
                        <p className="font-medium">{t.sections.contact.police}</p>
                        <p className="text-lg font-bold text-blue-700">197 - 193</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-blue-600">
                      <Phone className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">🚑</span>
                      <div>
                        <p className="font-medium">{t.sections.contact.ambulance}</p>
                        <p className="text-lg font-bold text-green-700">190</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-green-600">
                      <Phone className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-orange-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">🚒</span>
                      <div>
                        <p className="font-medium">{t.sections.contact.civilProtection}</p>
                        <p className="text-lg font-bold text-orange-700">198</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-orange-600">
                      <Phone className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Administration Contact */}
            <Card className="shadow-lg">
              <CardContent className="p-4 space-y-3">
                <h3 className="font-bold text-blue-700 flex items-center gap-2">
                  🏛️ {language === 'ar' ? 'التواصل مع إدارة شرطة المرور' : 'Contact Administration'}
                </h3>
                
                <div className="p-4 bg-blue-50 rounded-xl">
                  <div className="flex items-center gap-3 text-blue-700">
                    <MapPin className="h-5 w-5" />
                    <div>
                      <p className="text-xs text-gray-500">{language === 'ar' ? 'العنوان' : 'Address'}</p>
                      <span className="font-medium">{t.address}</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-xl">
                  <p className="text-xs text-gray-500 mb-2">📞 {language === 'ar' ? 'الهواتف' : 'Phones'}</p>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    {['71 343 201', '71 342 875', '71 342 787'].map((phone, idx) => (
                      <div key={idx} className="p-2 bg-white rounded-lg border text-sm font-mono font-bold">
                        {phone}
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="p-4 bg-purple-50 rounded-xl">
                  <span className="text-2xl mr-2">📠</span>
                  <span className="text-xs text-gray-500">{language === 'ar' ? 'الفاكس' : 'Fax'}:</span>
                  <span className="font-mono font-bold ml-2">71 343 146</span>
                </div>
                
                <div className="p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border-2 border-cyan-200">
                  <p className="text-xs text-gray-500 mb-1">📧 {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</p>
                  <a href="mailto:d.police.circulation.tun@gmail.com" className="font-bold text-cyan-700 text-lg underline">
                    d.police.circulation.tun@gmail.com
                  </a>
                </div>
                
                <div className="p-4 bg-green-50 rounded-xl flex items-center gap-2">
                  <Clock className="h-5 w-5 text-green-600" />
                  <span className="text-sm text-green-700 font-medium">{t.sections.contact.workingHours}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Services Section */}
        {activeTab === 'services' && (
          <div className="space-y-4">
            <Card className="bg-gradient-to-l from-purple-600 to-purple-700 text-white border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-1">{t.sections.services.title}</h2>
                    <p className="text-purple-100 text-sm">{t.sections.services.subtitle}</p>
                  </div>
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <Settings className="h-8 w-8" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 gap-2">
              {[
                { icon: '🚗', title: t.sections.services.license, color: 'bg-blue-50' },
                { icon: '🚧', title: t.sections.services.roadworkPermit, color: 'bg-green-50' },
                { icon: '📷', title: t.sections.services.radar, color: 'bg-indigo-50' },
                { icon: '⚠️', title: t.sections.services.violations, color: 'bg-orange-50' },
                { icon: '🛡️', title: t.sections.services.accidents, color: 'bg-red-50' },
                { icon: '💳', title: t.sections.services.eservices, color: 'bg-purple-50' },
                { icon: '❓', title: t.sections.services.faq, color: 'bg-cyan-50' },
              ].map((service, index) => (
                <Card key={index} className={`${service.color} cursor-pointer hover:shadow-lg transition-shadow`}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="text-2xl">{service.icon}</div>
                      <span className="font-medium text-gray-700">{service.title}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-blue-700 to-blue-800 text-white mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-2 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-bold">{t.appName}</span>
            </div>
            <div className="text-blue-200">{t.address}</div>
            <div className="text-xs text-blue-200">🇹🇳 {t.country}</div>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50">
        <div className="grid grid-cols-4 gap-1 p-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 px-2 py-2 rounded-lg text-xs ${
                activeTab === tab.id ? 'bg-blue-100 text-blue-700' : 'text-gray-500'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span className="text-[10px]">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
