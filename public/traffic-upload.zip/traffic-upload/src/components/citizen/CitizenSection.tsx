'use client';

import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  Camera,
  Video,
  MapPin,
  Send,
  Upload,
  X,
  AlertTriangle,
  Construction,
  Car,
  Clock,
  CheckCircle,
  Users
} from 'lucide-react';

const reportTypes = [
  { value: 'accident', label: 'حادث مروري', icon: '🚗', color: 'bg-red-500' },
  { value: 'traffic_jam', label: 'إكتظاظ مروري', icon: '🚦', color: 'bg-orange-500' },
  { value: 'roadwork', label: 'أشغال بالطريق', icon: '🚧', color: 'bg-amber-500' },
  { value: 'hazard', label: 'خطر على الطريق', icon: '⚠️', color: 'bg-yellow-500' },
  { value: 'closure', label: 'إغلاق طريق', icon: '🚫', color: 'bg-red-600' },
  { value: 'other', label: 'أخرى', icon: '📍', color: 'bg-gray-500' },
];

export function CitizenSection() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedType, setSelectedType] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // الحصول على موقع المستخدم
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setLocation('تم تحديد موقعك الحالي');
          toast.success('تم تحديد موقعك بنجاح');
        },
        (error) => {
          toast.error('لم نتمكن من تحديد موقعك');
        }
      );
    }
  };

  // رفع الصور
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      if (images.length + files.length > 5) {
        toast.error('يمكنك رفع 5 صور كحد أقصى');
        return;
      }
      Array.from(files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            setImages((prev) => [...prev, e.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  // رفع الفيديو
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        toast.error('حجم الفيديو يجب أن يكون أقل من 50 ميجابايت');
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        setVideoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // إزالة صورة
  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  // إرسال البلاغ
  const handleSubmit = async () => {
    if (!selectedType || !title || !location) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: selectedType,
          title,
          description,
          location,
          latitude: userLocation?.lat,
          longitude: userLocation?.lng,
          images: images.length > 0 ? images : undefined,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setShowSuccess(true);
        // إعادة تعيين النموذج
        setSelectedType('');
        setTitle('');
        setDescription('');
        setLocation('');
        setImages([]);
        setVideoPreview(null);
        setUserLocation(null);
      }
    } catch (error) {
      toast.error('حدث خطأ في إرسال البلاغ');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header Card */}
      <Card className="bg-gradient-to-l from-green-600 to-green-700 text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-1">فضاء المواطن المسؤول</h2>
              <p className="text-green-100 text-sm">ساهم في تحسين السلامة المرورية</p>
            </div>
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
              <Users className="h-8 w-8" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info Cards */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4 text-center">
          <Camera className="h-8 w-8 mx-auto text-blue-500 mb-2" />
          <p className="text-sm font-medium">أرسل صوراً</p>
          <p className="text-xs text-muted-foreground">وثّق الحالة</p>
        </Card>
        <Card className="p-4 text-center">
          <Video className="h-8 w-8 mx-auto text-purple-500 mb-2" />
          <p className="text-sm font-medium">أرسل فيديو</p>
          <p className="text-xs text-muted-foreground">سجّل الموقف</p>
        </Card>
      </div>

      {/* Main Form */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Send className="h-5 w-5 text-green-500" />
            إرسال تنبيه جديد
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* نوع البلاغ */}
          <div className="space-y-2">
            <Label>نوع التنبيه *</Label>
            <div className="grid grid-cols-3 gap-2">
              {reportTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => setSelectedType(type.value)}
                  className={`p-3 rounded-lg border-2 text-center transition-all ${
                    selectedType === type.value
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/30'
                      : 'border-transparent bg-muted hover:border-blue-200'
                  }`}
                >
                  <span className="text-2xl">{type.icon}</span>
                  <p className="text-xs mt-1">{type.label}</p>
                </button>
              ))}
            </div>
          </div>

          {/* العنوان */}
          <div className="space-y-2">
            <Label htmlFor="title">عنوان التنبيه *</Label>
            <Input
              id="title"
              placeholder="مثال: حادث مروري على الطريق السيار"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* الوصف */}
          <div className="space-y-2">
            <Label htmlFor="description">وصف تفصيلي</Label>
            <Textarea
              id="description"
              placeholder="أضف تفاصيل إضافية..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {/* الموقع */}
          <div className="space-y-2">
            <Label>الموقع *</Label>
            <div className="flex gap-2">
              <Input
                placeholder="أدخل العنوان أو حدد موقعك"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                onClick={getCurrentLocation}
                className="shrink-0"
              >
                <MapPin className="h-4 w-4" />
              </Button>
            </div>
            {userLocation && (
              <p className="text-xs text-green-600 flex items-center gap-1">
                <CheckCircle className="h-3 w-3" />
                تم تحديد الموقع بنجاح
              </p>
            )}
          </div>

          {/* رفع الصور */}
          <div className="space-y-2">
            <Label>صور (اختياري - 5 صور كحد أقصى)</Label>
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleImageUpload}
            />
            <div className="flex flex-wrap gap-2">
              {images.map((img, index) => (
                <div key={index} className="relative w-20 h-20">
                  <img
                    src={img}
                    alt={`صورة ${index + 1}`}
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <button
                    onClick={() => removeImage(index)}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              {images.length < 5 && (
                <button
                  onClick={() => imageInputRef.current?.click()}
                  className="w-20 h-20 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-muted-foreground hover:border-blue-400 hover:text-blue-500 transition-colors"
                >
                  <Camera className="h-5 w-5" />
                  <span className="text-xs">إضافة</span>
                </button>
              )}
            </div>
          </div>

          {/* رفع الفيديو */}
          <div className="space-y-2">
            <Label>فيديو (اختياري - 50MB كحد أقصى)</Label>
            <input
              ref={videoInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={handleVideoUpload}
            />
            {videoPreview ? (
              <div className="relative">
                <video
                  src={videoPreview}
                  controls
                  className="w-full rounded-lg max-h-48"
                />
                <button
                  onClick={() => setVideoPreview(null)}
                  className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => videoInputRef.current?.click()}
                className="w-full p-4 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-muted-foreground hover:border-purple-400 hover:text-purple-500 transition-colors"
              >
                <Video className="h-8 w-8 mb-2" />
                <span className="text-sm">اضغط لرفع فيديو</span>
              </button>
            )}
          </div>

          {/* زر الإرسال */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="w-full bg-gradient-to-l from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
          >
            {isSubmitting ? (
              <>
                <Clock className="h-4 w-4 ml-2 animate-spin" />
                جاري الإرسال...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 ml-2" />
                إرسال التنبيه
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="text-center">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              تم إرسال تنبيهك بنجاح!
            </DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground mb-4">
            شكراً لمساهمتك في تحسين السلامة المرورية. سيتم مراجعة تنبيهك وإضافته للخرائط.
          </p>
          <Button onClick={() => setShowSuccess(false)}>
            إرسال تنبيه آخر
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
