'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  AlertTriangle, 
  Clock, 
  MapPin, 
  ChevronLeft, 
  ChevronRight,
  Phone,
  Info
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

interface NewsItem {
  id: string;
  title: string;
  content: string;
  category: 'urgent' | 'info' | 'warning';
  source?: string;
  createdAt: string;
}

const categoryStyles = {
  urgent: {
    bg: 'bg-red-500',
    text: 'text-white',
    border: 'border-red-500',
    icon: AlertTriangle,
    label: 'عاجل',
  },
  warning: {
    bg: 'bg-amber-500',
    text: 'text-white',
    border: 'border-amber-500',
    icon: AlertTriangle,
    label: 'تنبيه',
  },
  info: {
    bg: 'bg-blue-500',
    text: 'text-white',
    border: 'border-blue-500',
    icon: Info,
    label: 'معلومات',
  },
};

export function NewsSection() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 3;

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    try {
      const res = await fetch('/api/news');
      const data = await res.json();
      if (data.success) {
        setNews(data.data);
      }
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalPages = Math.ceil(news.length / itemsPerPage);
  const displayedNews = news.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  if (loading) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <span>📰</span> المستجدات والأخبار
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3 bg-gradient-to-l from-primary/10 to-transparent">
        <CardTitle className="text-lg flex items-center justify-between">
          <span className="flex items-center gap-2">
            <span>📰</span> المستجدات والأخبار
          </span>
          {news.filter((n) => n.category === 'urgent').length > 0 && (
            <Badge variant="destructive" className="animate-pulse">
              {news.filter((n) => n.category === 'urgent').length} عاجل
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[280px]">
          <div className="p-4 space-y-3">
            {displayedNews.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <Info className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>لا توجد أخبار حالياً</p>
              </div>
            ) : (
              displayedNews.map((item) => {
                const style = categoryStyles[item.category];
                const Icon = style.icon;
                return (
                  <div
                    key={item.id}
                    className={`p-3 rounded-lg border-r-4 ${style.border} bg-muted/50 hover:bg-muted transition-colors`}
                  >
                    <div className="flex items-start gap-2">
                      <Badge className={`${style.bg} ${style.text} shrink-0`}>
                        <Icon className="h-3 w-3 ml-1" />
                        {style.label}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm leading-tight mb-1">
                          {item.title}
                        </h4>
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {item.content}
                        </p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                          {item.source && (
                            <span className="flex items-center gap-1">
                              <Info className="h-3 w-3" />
                              {item.source}
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatDistanceToNow(new Date(item.createdAt), {
                              addSuffix: true,
                              locale: ar,
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
        
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-3 border-t bg-muted/30">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages - 1))}
              disabled={currentPage >= totalPages - 1}
            >
              <ChevronRight className="h-4 w-4" />
              السابق
            </Button>
            <span className="text-xs text-muted-foreground">
              {currentPage + 1} / {totalPages}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 0))}
              disabled={currentPage <= 0}
            >
              التالي
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
